import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from sim11ah.metrics import snapshot
from sim11ah.io_utils import safe_export_csv


class StatCard(tk.Frame):
    def __init__(self, parent, title: str):
        super().__init__(parent, bd=1, relief="solid", padx=10, pady=8)
        self.title = tk.Label(self, text=title, font=("Arial", 11, "bold"))
        self.big = tk.Label(self, text="-", font=("Arial", 18, "bold"))
        self.sub = tk.Label(self, text="", font=("Arial", 10))
        self.title.pack(anchor="w")
        self.big.pack(anchor="w")
        self.sub.pack(anchor="w")

    def set(self, big: str, sub: str = ""):
        self.big.config(text=big)
        self.sub.config(text=sub)


class SimpleLineChart(tk.Canvas):
    def __init__(self, parent, width=420, height=160):
        super().__init__(parent, width=width, height=height, bd=1, relief="solid")
        self.w = width
        self.h = height

    def draw(self, series):
        self.delete("all")
        if len(series) < 2:
            return

        xs = [x for x, _ in series]
        ys = [y for _, y in series]
        xmin, xmax = min(xs), max(xs)
        ymin, ymax = min(ys), max(ys)

        if xmax == xmin:
            xmax += 1.0
        if ymax == ymin:
            ymax += 1.0

        def mapx(x):
            return 25 + (x - xmin) * (self.w - 50) / (xmax - xmin)

        def mapy(y):
            return (self.h - 25) - (y - ymin) * (self.h - 50) / (ymax - ymin)

        pts = []
        for x, y in series:
            pts.extend([mapx(x), mapy(y)])

        self.create_line(*pts, width=2)
        self.create_text(10, 10, anchor="nw", text="Latency(avg) vs time", font=("Arial", 9))


class Dashboard(tk.Tk):
    def __init__(self, sim):
        super().__init__()
        self.sim = sim
        self.running = False

        self.lat_series = []  # (time, lat_avg)

        self.title("IEEE 802.11ah-like Simulator Dashboard (Tkinter)")
        self.geometry("1100x700")

        # Top cards
        cards = tk.Frame(self)
        cards.pack(fill="x", padx=10, pady=10)

        self.card_pdr = StatCard(cards, "Overall E2E PDR")
        self.card_lat = StatCard(cards, "Overall E2E Latency")
        self.card_thr = StatCard(cards, "Throughput")
        self.card_err = StatCard(cards, "Errors")

        for c in (self.card_pdr, self.card_lat, self.card_thr, self.card_err):
            c.pack(side="left", padx=6)

        # Middle charts + controls
        mid = tk.Frame(self)
        mid.pack(fill="both", expand=True, padx=10, pady=5)

        left = tk.Frame(mid)
        left.pack(side="left", fill="both", expand=True)

        right = tk.Frame(mid)
        right.pack(side="right", fill="y")

        self.chart = SimpleLineChart(left, width=520, height=220)
        self.chart.pack(pady=5)

        # RAW attempt/success summary (text)
        self.raw_box = tk.Text(left, height=8, width=70)
        self.raw_box.pack(fill="x", pady=5)

        # Log viewer
        tk.Label(left, text="Log Viewer (tail)", font=("Arial", 11, "bold")).pack(anchor="w", pady=(10, 0))
        self.log_text = tk.Text(left, height=16)
        self.log_text.pack(fill="both", expand=True)

        # Controls
        tk.Label(right, text="Controls", font=("Arial", 12, "bold")).pack(pady=(0, 10))

        self.btn_start = ttk.Button(right, text="Start", command=self.start)
        self.btn_stop = ttk.Button(right, text="Stop", command=self.stop)
        self.btn_step = ttk.Button(right, text="Step (0.5s sim)", command=self.step_once)
        self.btn_export = ttk.Button(right, text="Export Logs CSV", command=self.export_csv)

        self.btn_start.pack(fill="x", pady=4)
        self.btn_stop.pack(fill="x", pady=4)
        self.btn_step.pack(fill="x", pady=4)
        self.btn_export.pack(fill="x", pady=10)

        # Simulation speed
        tk.Label(right, text="GUI update (ms)").pack(anchor="w")
        self.update_ms = tk.IntVar(value=150)
        ttk.Spinbox(right, from_=50, to=1000, textvariable=self.update_ms).pack(fill="x", pady=3)

        tk.Label(right, text="Step dt (sim seconds)").pack(anchor="w")
        self.step_dt = tk.DoubleVar(value=0.2)
        ttk.Spinbox(right, from_=0.01, to=5.0, increment=0.05, textvariable=self.step_dt).pack(fill="x", pady=3)

        ttk.Separator(right, orient="horizontal").pack(fill="x", pady=10)

        self.status = tk.StringVar(value="Ready")
        tk.Label(right, textvariable=self.status, wraplength=220, justify="left").pack(anchor="w")

        # Begin periodic refresh
        self.after(self.update_ms.get(), self._tick)

    def start(self):
        self.running = True
        self.status.set("Running...")

    def stop(self):
        self.running = False
        self.status.set("Stopped.")

    def step_once(self):
        self.sim.step(float(self.step_dt.get()))
        self._refresh()

    def _tick(self):
        if self.running:
            self.sim.step(float(self.step_dt.get()))
            self._refresh()
        self.after(self.update_ms.get(), self._tick)

    def _refresh(self):
        m = snapshot(self.sim)

        self.card_pdr.set(f"{m['pdr']*100:.3f}%", f"TX:{m['tx']}  RX:{m['rx']}  Drop:{m['drop']}")
        self.card_lat.set(f"Avg {m['lat_avg']:.2f}s", f"Max {m['lat_max']:.2f}s  Min {m['lat_min']:.2f}s")
        self.card_thr.set(f"{m['thr_bps']:.1f} bps", f"Time {m['time']:.2f}s")
        self.card_err.set(f"Coll {m['collisions']} / PER {m['per_drops']}", f"ACK_TO {m['ack_to']} / Retries {m['mac_retries']}")

        # chart
        self.lat_series.append((m["time"], m["lat_avg"]))
        if len(self.lat_series) > 200:
            self.lat_series = self.lat_series[-200:]
        self.chart.draw(self.lat_series)

        # RAW summary
        self.raw_box.delete("1.0", "end")
        if self.sim.config["mac"]["raw_enable"]:
            raw_attempts = dict(sorted(m["raw_attempts"].items()))
            raw_success = dict(sorted(m["raw_success"].items()))
            self.raw_box.insert("end", f"RAW attempts: {raw_attempts}\n")
            self.raw_box.insert("end", f"RAW success:  {raw_success}\n")
        else:
            self.raw_box.insert("end", "RAW disabled.\n")

        # log tail
        tail = self.sim.logger.dump_logs(human_readable=True, limit=80)
        self.log_text.delete("1.0", "end")
        self.log_text.insert("end", tail)

        self.status.set(f"Sim time: {m['time']:.3f}s | Logs: {len(self.sim.logger.logs)}")

    def export_csv(self):
        path = filedialog.asksaveasfilename(
            title="Save simulator logs",
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            out = safe_export_csv(self.sim.logger, path)
            messagebox.showinfo("Export OK", f"Saved logs to:\n{out}")
        except Exception as e:
            messagebox.showerror("Export failed", str(e))
