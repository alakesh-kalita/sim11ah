from typing import Any, Dict

from sim11ah.phy import PhyLayer
from sim11ah.mac import MacLayer
from sim11ah.net import NetworkLayer
from sim11ah.tp import TransportLayer
from sim11ah.app import ApplicationLayer


class Node:
    def __init__(self, node_id: int, sim: "Simulator"):
        self.node_id = node_id
        self.sim = sim
        self.phy: PhyLayer = None  # type: ignore
        self.mac: MacLayer = None  # type: ignore
        self.net: NetworkLayer = None  # type: ignore
        self.transport: TransportLayer = None  # type: ignore
        self.app: ApplicationLayer = None  # type: ignore

    def build_layers(self, cfg: Dict[str, Any]) -> None:
        self.phy = PhyLayer(self, cfg)
        self.mac = MacLayer(self, cfg)
        self.net = NetworkLayer(self, cfg)
        self.transport = TransportLayer(self, cfg)
        self.app = ApplicationLayer(self, cfg)
