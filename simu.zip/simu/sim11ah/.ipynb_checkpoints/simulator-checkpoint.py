from typing import Any, Dict, List, Optional, Tuple

from sim11ah.engine import EventEngine
from sim11ah.logger import SimLogger
from sim11ah.stats import SimStats
from sim11ah.models import MacFrame, NetPDU, Packet
from sim11ah.topology import Topology


class Simulator:
    def __init__(self, config: Dict[str, Any], seed: int):
        self.config = config
        self.engine = EventEngine(seed=seed)
        self.logger = SimLogger()
        self.stats = SimStats()
        self.topology: Optional[Topology] = None
        self.nodes: Dict[int, "Node"] = {}
        self.frame_seq_ctr: int = 0
        self.packet_seq_ctr: int = 0

        # Global medium occupancy: (start, end, tx_id, dst_id, frame_seq)
        self._medium_tx: List[Tuple[float, float, int, int, int]] = []

    def medium_is_busy(self, t: float) -> bool:
        for t0, t1, _tx, _dst, _fseq in self._medium_tx:
            if t0 <= t < t1:
                return True
        return False

    def medium_next_idle_time(self, t: float) -> float:
        next_end: Optional[float] = None
        for t0, t1, _tx, _dst, _fseq in self._medium_tx:
            if t0 <= t < t1:
                if next_end is None or t1 < next_end:
                    next_end = t1
        return t if next_end is None else next_end

    def next_frame_seq(self) -> int:
        self.frame_seq_ctr += 1
        return self.frame_seq_ctr

    def next_packet_seq(self) -> int:
        self.packet_seq_ctr += 1
        return self.packet_seq_ctr

    def log(self, *,
            node_id: int,
            layer: str,
            event: str,
            details: Optional[Dict[str, Any]] = None,
            frame: Optional[MacFrame] = None,
            net_pdu: Optional[NetPDU] = None,
            packet: Optional[Packet] = None) -> None:

        d = dict(details) if details else {}

        top: Dict[str, Any] = {
            "time": self.engine.now,
            "node_id": node_id,
            "layer": layer,
            "event": event,
            "packet_seq": None,
            "net_seq": None,
            "frame_seq": None,
            "tx_seq": None,
            "ftype": None,
            "src": None,
            "dst": None,
            "details": d
        }

        if packet is None and net_pdu is not None:
            packet = net_pdu.packet
        if net_pdu is None and frame is not None:
            net_pdu = frame.net_pdu

        if packet is not None:
            top["packet_seq"] = getattr(packet, "packet_seq", None)
            top["src"] = getattr(packet, "src", top["src"])
            top["dst"] = getattr(packet, "dst", top["dst"])

        if net_pdu is not None:
            top["net_seq"] = getattr(net_pdu, "net_seq", None)
            pkt2 = getattr(net_pdu, "packet", None)
            if pkt2 is not None and top["packet_seq"] is None:
                top["packet_seq"] = getattr(pkt2, "packet_seq", None)
                top["src"] = getattr(pkt2, "src", top["src"])
                top["dst"] = getattr(pkt2, "dst", top["dst"])

        if frame is not None:
            top["frame_seq"] = getattr(frame, "frame_seq", None)
            top["tx_seq"] = getattr(frame, "tx_seq", None)
            top["ftype"] = getattr(frame, "ftype", None)
            top["src"] = getattr(frame, "src", top["src"])
            top["dst"] = getattr(frame, "dst", top["dst"])
            pdu2 = getattr(frame, "net_pdu", None)
            if pdu2 is not None and top["net_seq"] is None:
                top["net_seq"] = getattr(pdu2, "net_seq", None)

        self.logger.log(top)

    def run(self, sim_time: float) -> None:
        if self.nodes and 0 in self.nodes:
            self.nodes[0].mac.ap_start_beacons()
        for _, n in self.nodes.items():
            n.app.start()
        self.engine.run(until=sim_time)

    def step(self, dt: float) -> None:
        """GUI-friendly stepping: run the engine up to now+dt."""
        end = self.engine.now + max(0.0, dt)
        self.engine.run(until=end)
