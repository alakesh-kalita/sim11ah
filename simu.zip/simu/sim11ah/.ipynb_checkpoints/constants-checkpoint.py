class FrameType:
    DATA = "DATA"
    ACK = "ACK"
    BEACON = "BEACON"
    RTS = "RTS"
    CTS = "CTS"


class MacState:
    IDLE = "IDLE"
    BACKOFF = "BACKOFF"
    TX = "TX"
    WAIT_ACK = "WAIT_ACK"
    RX = "RX"
    NAV = "NAV"
    RAW_SLEEP = "RAW_SLEEP"
