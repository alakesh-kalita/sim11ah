from dataclasses import dataclass, field
from typing import Dict, List
from collections import defaultdict


@dataclass
class SimStats:
    packets_generated: int = 0
    packets_delivered: int = 0
    packets_dropped: int = 0
    mac_retries: int = 0
    phy_collisions: int = 0
    phy_per_drops: int = 0
    mac_ack_timeouts: int = 0
    mac_tx_attempts: int = 0

    delivered_by_dst: Dict[int, int] = field(default_factory=lambda: defaultdict(int))
    generated_by_src: Dict[int, int] = field(default_factory=lambda: defaultdict(int))
    delays: List[float] = field(default_factory=list)

    raw_slot_tx_attempts: Dict[int, int] = field(default_factory=lambda: defaultdict(int))
    raw_slot_data_success: Dict[int, int] = field(default_factory=lambda: defaultdict(int))
