from typing import Any, Deque, Dict, Optional
from collections import deque

from sim11ah.constants import FrameType, MacState
from sim11ah.models import MacFrame, NetPDU, Packet


class MacLayer:
    def __init__(self, node: "Node", cfg: Dict[str, Any]):
        self.node = node
        self.sim = node.sim
        self.cfg = cfg
        self.state = MacState.IDLE

        mac_cfg = cfg["mac"]
        self.sifs = float(mac_cfg["sifs"])
        self.difs = float(mac_cfg["difs"])
        self.ack_timeout = float(mac_cfg["ack_timeout"])
        self.cw_min = int(mac_cfg["cw_min"])
        self.cw_max = int(mac_cfg["cw_max"])
        self.retry_limit = int(mac_cfg["retry_limit"])
        self.ack_size_bytes = int(mac_cfg["ack_size_bytes"])
        self.beacon_size_bytes = int(mac_cfg["beacon_size_bytes"])
        self.data_mac_overhead_bytes = int(mac_cfg["data_mac_overhead_bytes"])

        self.raw_enable = bool(mac_cfg["raw_enable"])
        self.beacon_interval = float(mac_cfg["beacon_interval"])
        self.dtim_period = int(mac_cfg["dtim_period"])
        self.raw_slot_duration = float(mac_cfg["raw_slot_duration"])
        self.raw_num_slots = int(mac_cfg["raw_num_slots"])
        self.raw_assigned_slot: Optional[int] = None

        self.raw_allowed: bool = (not self.raw_enable) or (self.node.node_id == 0)
        self._raw_slot_enter_t: float = 0.0
        self._raw_slot_exit_t: float = 0.0

        self._txq: Deque[NetPDU] = deque()

        self._backoff_slots_left: Optional[int] = None
        self._cw: int = self.cw_min
        self._pending_frame: Optional[MacFrame] = None
        self._waiting_ack_for_frame_seq: Optional[int] = None

        self._tx_seq_ctr = 0
        self._nav_end: float = 0.0
        self._idle_since: Optional[float] = None

        self._backoff_tick_scheduled: bool = False

    def _log(self, event: str, details: Dict[str, Any],
             frame: Optional[MacFrame] = None,
             net_pdu: Optional[NetPDU] = None,
             packet: Optional[Packet] = None) -> None:
        self.sim.log(node_id=self.node.node_id, layer="MAC", event=event,
                     details=details, frame=frame, net_pdu=net_pdu, packet=packet)

    def _is_busy(self) -> bool:
        if self.sim.engine.now < self._nav_end:
            return True
        return self.node.phy.is_channel_busy(self.node.node_id)

    def _can_tx_now(self) -> bool:
        if not self.raw_enable:
            return True
        if self.node.node_id == 0:
            return True
        return self.raw_allowed

    def _schedule_backoff_tick(self, delay: float) -> None:
        if not self._backoff_tick_scheduled:
            self._backoff_tick_scheduled = True
            self.sim.engine.schedule_in(delay, self._backoff_tick)

    def _update_state_idleish(self) -> None:
        if self.raw_enable and self.node.node_id != 0 and not self.raw_allowed:
            if self.state != MacState.RAW_SLEEP:
                self.state = MacState.RAW_SLEEP
                self._log("RAW_SLEEP_ENTER", {
                    "slot": self.raw_assigned_slot,
                    "enter": self._raw_slot_enter_t,
                    "exit": self._raw_slot_exit_t
                })
            return

        if self.state == MacState.RAW_SLEEP:
            return
        if self.state not in (MacState.IDLE, MacState.BACKOFF):
            return

        if self._pending_frame is None and self._txq:
            net_pdu = self._txq[0]
            self._pending_frame = self._make_data_frame(net_pdu)
            self._cw = self.cw_min

        if self._pending_frame is not None:
            self._start_or_continue_backoff()

    def send_down(self, net_pdu: NetPDU) -> None:
        self._txq.append(net_pdu)
        self._log("ENQUEUE", {"q_len": len(self._txq), "next_hop": net_pdu.next_hop}, net_pdu=net_pdu)
        self._update_state_idleish()

    def recv_up_from_phy(self, frame: MacFrame, collided: bool, per_drop: bool, rx_ok: bool) -> None:
        if not rx_ok:
            self._log("RX_DROP", {"collided": collided, "per_drop": per_drop}, frame=frame)
            return

        self._log("RX_OK", {"retry": frame.retry}, frame=frame)

        if frame.ftype == FrameType.BEACON:
            self._handle_beacon(frame)
            return

        if frame.dst not in (self.node.node_id, -1):
            return

        if frame.ftype == FrameType.ACK:
            if self.state == MacState.WAIT_ACK and self._waiting_ack_for_frame_seq == frame.ctrl.get("ack_for_frame_seq"):
                self._log("ACK_RX", {"ack_for_frame_seq": self._waiting_ack_for_frame_seq}, frame=frame)
                self._on_data_success()
            return

        if frame.ftype == FrameType.DATA:
            if frame.net_pdu is not None:
                self.node.net.recv_up_from_mac(frame.net_pdu)
            if frame.dst != -1:
                self.sim.engine.schedule_in(self.sifs, self._send_ack, frame.src, frame.frame_seq)

    def _send_ack(self, dst: int, ack_for_frame_seq: int) -> None:
        if self._is_busy():
            now = self.sim.engine.now
            t_idle = self.sim.medium_next_idle_time(now)
            delay = max(self.node.phy.slot_time, (t_idle - now))
            self.sim.engine.schedule_in(delay, self._send_ack, dst, ack_for_frame_seq)
            return

        self._tx_seq_ctr += 1
        ack = MacFrame(
            ftype=FrameType.ACK,
            src=self.node.node_id,
            dst=dst,
            size_bytes=self.ack_size_bytes,
            frame_seq=self.sim.next_frame_seq(),
            tx_seq=self._tx_seq_ctr,
            retry=0,
            net_pdu=None,
            ctrl={"ack_for_frame_seq": ack_for_frame_seq}
        )
        self._log("TX_ACK", {"ack_for_frame_seq": ack_for_frame_seq}, frame=ack)
        self.node.phy.send(ack, tx_id=self.node.node_id, rx_id=dst)

    def _make_data_frame(self, net_pdu: NetPDU) -> MacFrame:
        self._tx_seq_ctr += 1
        size_bytes = self.data_mac_overhead_bytes + net_pdu.packet.size_bytes + int(self.cfg["net"]["net_header_bytes"])
        return MacFrame(
            ftype=FrameType.DATA,
            src=self.node.node_id,
            dst=net_pdu.next_hop,
            size_bytes=size_bytes,
            frame_seq=self.sim.next_frame_seq(),
            tx_seq=self._tx_seq_ctr,
            retry=0,
            net_pdu=net_pdu,
            ctrl={}
        )

    def _start_or_continue_backoff(self) -> None:
        if not self._can_tx_now():
            self._update_state_idleish()
            return
        if self.state not in (MacState.IDLE, MacState.BACKOFF):
            return

        if self._backoff_slots_left is None:
            bo = self.sim.engine.rng.randint(0, self._cw)
            self._backoff_slots_left = bo
            self.state = MacState.BACKOFF
            self._idle_since = None
            self._log("BACKOFF_START", {"cw": self._cw, "slots": bo}, frame=self._pending_frame)
            self._schedule_backoff_tick(self.node.phy.slot_time)
        else:
            self._schedule_backoff_tick(self.node.phy.slot_time)

    def _backoff_tick(self) -> None:
        self._backoff_tick_scheduled = False

        if not self._can_tx_now():
            self._log("BACKOFF_ABORT_RAW", {"slots_left": self._backoff_slots_left}, frame=self._pending_frame)
            self._backoff_slots_left = None
            self.state = MacState.RAW_SLEEP
            self._idle_since = None
            return

        if self._pending_frame is None:
            self._backoff_slots_left = None
            self.state = MacState.IDLE
            self._idle_since = None
            return

        if self._is_busy():
            self._log("BACKOFF_FREEZE", {"slots_left": self._backoff_slots_left}, frame=self._pending_frame)
            self._idle_since = None
            now = self.sim.engine.now
            t_idle = self.sim.medium_next_idle_time(now)
            delay = max(self.node.phy.slot_time, (t_idle - now))
            self._schedule_backoff_tick(delay)
            return

        now = self.sim.engine.now
        if self._idle_since is None:
            self._idle_since = now
            self._schedule_backoff_tick(self.node.phy.slot_time)
            return

        if (now - self._idle_since) < self.difs:
            self._schedule_backoff_tick(self.node.phy.slot_time)
            return

        if self._backoff_slots_left is None:
            self._backoff_slots_left = 0

        if self._backoff_slots_left > 0:
            self._backoff_slots_left -= 1
            self._schedule_backoff_tick(self.node.phy.slot_time)
            return

        self._log("BACKOFF_END", {"cw": self._cw}, frame=self._pending_frame)
        self._backoff_slots_left = None
        self._idle_since = None
        self._tx_attempt()

    def _tx_attempt(self) -> None:
        if self._pending_frame is None:
            self.state = MacState.IDLE
            return
        if not self._can_tx_now():
            self.state = MacState.RAW_SLEEP
            return
        if self._is_busy():
            self.state = MacState.BACKOFF
            self._start_or_continue_backoff()
            return

        fr = self._pending_frame
        self.state = MacState.TX
        self.sim.stats.mac_tx_attempts += 1

        if self.raw_enable and self.node.node_id != 0 and self.raw_assigned_slot is not None:
            self.sim.stats.raw_slot_tx_attempts[self.raw_assigned_slot] += 1

        self._log("TX_ATTEMPT", {"cw": self._cw, "retry": fr.retry}, frame=fr)
        self.node.phy.send(fr, tx_id=self.node.node_id, rx_id=fr.dst)

        if fr.ftype == FrameType.DATA and fr.dst != -1:
            self.state = MacState.WAIT_ACK
            self._waiting_ack_for_frame_seq = fr.frame_seq
            to = self._compute_ack_timeout(fr)
            self._log("ACK_TIMEOUT_SET", {"timeout_s": to}, frame=fr)
            self.sim.engine.schedule_in(to, self._ack_timeout, fr.frame_seq)
        else:
            self._on_data_success()

    def _compute_ack_timeout(self, data_frame: MacFrame) -> float:
        if self.sim.topology is None:
            return self.ack_timeout
        try:
            lk = self.sim.topology.get_link(self.node.node_id, data_frame.dst)
        except KeyError:
            return self.ack_timeout

        mode = self.node.phy.default_mode
        rate = int(self.node.phy.mode_table.get(mode, lk.rate_bps))
        t_data = self.node.phy.compute_tx_duration(data_frame, rate)

        ack = MacFrame(
            ftype=FrameType.ACK,
            src=data_frame.dst,
            dst=self.node.node_id,
            size_bytes=self.ack_size_bytes,
            frame_seq=0,
            tx_seq=0,
        )
        t_ack = self.node.phy.compute_tx_duration(ack, rate)

        guard = float(self.cfg["mac"].get("ack_guard", 0.0002))
        needed = t_data + 2.0 * float(lk.prop_delay) + self.sifs + t_ack + guard
        return max(float(self.ack_timeout), needed)

    def _ack_timeout(self, frame_seq: int) -> None:
        if self.state != MacState.WAIT_ACK:
            return
        if self._waiting_ack_for_frame_seq != frame_seq:
            return
        self.sim.stats.mac_ack_timeouts += 1
        self._log("ACK_TIMEOUT", {"waited_for_frame_seq": frame_seq}, frame=self._pending_frame)
        self._handle_retry_or_drop()

    def _handle_retry_or_drop(self) -> None:
        fr = self._pending_frame
        if fr is None:
            self.state = MacState.IDLE
            return

        fr.retry += 1
        self.sim.stats.mac_retries += 1
        self._log("RETRY", {"retry": fr.retry, "retry_limit": self.retry_limit}, frame=fr)

        if fr.retry > self.retry_limit:
            net_pdu = fr.net_pdu
            if net_pdu is not None:
                self.sim.stats.packets_dropped += 1
                self._log("DROP", {"reason": "retry_limit"}, frame=fr, net_pdu=net_pdu)

            if self._txq and fr.net_pdu is self._txq[0]:
                self._txq.popleft()

            self._pending_frame = None
            self._waiting_ack_for_frame_seq = None
            self._cw = self.cw_min
            self.state = MacState.IDLE
            self._update_state_idleish()
            return

        self._cw = min(self.cw_max, max(self.cw_min, (self._cw * 2 + 1)))
        fr.frame_seq = self.sim.next_frame_seq()
        fr.tx_seq = fr.tx_seq + 1
        self._waiting_ack_for_frame_seq = None
        self.state = MacState.IDLE
        self._update_state_idleish()

    def _on_data_success(self) -> None:
        fr = self._pending_frame
        if fr is None:
            self.state = MacState.IDLE
            return

        net_pdu = fr.net_pdu
        if net_pdu is not None:
            if self._txq and net_pdu is self._txq[0]:
                self._txq.popleft()
            self._log("TX_SUCCESS", {"retry": fr.retry, "next_hop": net_pdu.next_hop}, frame=fr, net_pdu=net_pdu)

            if self.raw_enable and self.node.node_id != 0 and self.raw_assigned_slot is not None:
                self.sim.stats.raw_slot_data_success[self.raw_assigned_slot] += 1

        self._pending_frame = None
        self._waiting_ack_for_frame_seq = None
        self._cw = self.cw_min
        self.state = MacState.IDLE
        self._update_state_idleish()

    # ===== RAW / Beacons =====

    def ap_start_beacons(self) -> None:
        if self.node.node_id != 0:
            return
        self._ap_beacon_count = 0
        self._log("AP_BEACON_SCHED_START", {
            "beacon_interval": self.beacon_interval,
            "dtim_period": self.dtim_period,
            "raw_enable": int(self.raw_enable)
        })
        self.sim.engine.schedule(self.sim.engine.now, self._ap_send_beacon)

    def _ap_send_beacon(self) -> None:
        if self.node.phy.is_channel_busy(self.node.node_id):
            now = self.sim.engine.now
            t_idle = self.sim.medium_next_idle_time(now)
            delay = max(self.node.phy.slot_time, (t_idle - now))
            self.sim.engine.schedule_in(delay, self._ap_send_beacon)
            return

        self._ap_beacon_count += 1
        is_dtim = (self._ap_beacon_count % self.dtim_period == 0)

        if self.raw_enable and is_dtim:
            raw_info = {"raw_num_slots": self.raw_num_slots, "raw_slot_duration": self.raw_slot_duration, "dtim": True}
        else:
            raw_info = {"dtim": is_dtim}

        beacon = MacFrame(
            ftype=FrameType.BEACON,
            src=0,
            dst=-1,
            size_bytes=self.beacon_size_bytes,
            frame_seq=self.sim.next_frame_seq(),
            tx_seq=self._ap_beacon_count,
            retry=0,
            net_pdu=None,
            ctrl=raw_info
        )

        self.sim.log(node_id=0, layer="MAC", event="TX_BEACON",
                     frame=beacon, details={"dtim": is_dtim, "raw": int(self.raw_enable and is_dtim)})

        self.node.phy.send(beacon, tx_id=0, rx_id=-1)
        self.sim.engine.schedule_in(self.beacon_interval, self._ap_send_beacon)

    def _handle_beacon(self, frame: MacFrame) -> None:
        if self.node.node_id == 0:
            return
        dtim = bool(frame.ctrl.get("dtim", False))
        if not (self.raw_enable and dtim):
            return

        if self.raw_assigned_slot is None:
            self.raw_assigned_slot = (self.node.node_id - 1) % max(1, self.raw_num_slots)

        raw_cycle_start = self.sim.engine.now + float(self.cfg["mac"].get("raw_guard", 0.0005))
        slot_start = raw_cycle_start + self.raw_assigned_slot * self.raw_slot_duration
        slot_end = slot_start + self.raw_slot_duration

        self._raw_slot_enter_t = slot_start
        self._raw_slot_exit_t = slot_end

        self.sim.engine.schedule(slot_start, self._raw_enter)
        self.sim.engine.schedule(slot_end, self._raw_exit)

        self._log("RAW_SCHEDULE", {
            "assigned_slot": self.raw_assigned_slot,
            "raw_cycle_start": raw_cycle_start,
            "slot_start": slot_start,
            "slot_end": slot_end,
            "raw_num_slots": self.raw_num_slots,
            "raw_slot_duration": self.raw_slot_duration
        }, frame=frame)

    def _raw_enter(self) -> None:
        if not self.raw_enable or self.node.node_id == 0:
            return
        self.raw_allowed = True
        self.state = MacState.IDLE
        self._log("RAW_SLOT_ENTER", {"slot": self.raw_assigned_slot})
        self._update_state_idleish()

    def _raw_exit(self) -> None:
        if not self.raw_enable or self.node.node_id == 0:
            return
        self.raw_allowed = False
        self._log("RAW_SLOT_EXIT", {"slot": self.raw_assigned_slot})
        if self.state == MacState.BACKOFF:
            self._log("BACKOFF_CLEAR_RAW_EXIT", {"slots_left": self._backoff_slots_left}, frame=self._pending_frame)
            self._backoff_slots_left = None
        if self.state != MacState.WAIT_ACK:
            self.state = MacState.RAW_SLEEP
