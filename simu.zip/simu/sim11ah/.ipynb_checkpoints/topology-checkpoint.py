from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class Link:
    a: int
    b: int
    rate_bps: int
    prop_delay: float
    per: float


class Topology:
    def __init__(self):
        self.links: Dict[Tuple[int, int], Link] = {}

    def add_link(self, a: int, b: int, rate_bps: int, prop_delay: float, per: float) -> None:
        lk = Link(a=a, b=b, rate_bps=rate_bps, prop_delay=prop_delay, per=per)
        self.links[(a, b)] = lk
        self.links[(b, a)] = Link(a=b, b=a, rate_bps=rate_bps, prop_delay=prop_delay, per=per)

    def get_link(self, src: int, dst: int) -> Link:
        return self.links[(src, dst)]


class StarBuilder:
    @staticmethod
    def build(sim: "Simulator", num_stas: int, link_cfg: Dict[str, Any]) -> List["Node"]:
        from sim11ah.node import Node  # local import to avoid circular
        topo = Topology()
        sim.topology = topo

        ap_id = 0
        nodes: List[Node] = [Node(node_id=ap_id, sim=sim)]
        for i in range(1, num_stas + 1):
            nodes.append(Node(node_id=i, sim=sim))

        for i in range(1, num_stas + 1):
            topo.add_link(ap_id, i,
                          rate_bps=int(link_cfg["rate_bps"]),
                          prop_delay=float(link_cfg["prop_delay"]),
                          per=float(link_cfg["per"]))

        sim.nodes = {n.node_id: n for n in nodes}
        for n in nodes:
            n.build_layers(sim.config)
        return nodes
