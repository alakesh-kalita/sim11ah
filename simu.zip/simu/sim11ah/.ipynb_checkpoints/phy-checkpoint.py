from dataclasses import dataclass
from typing import Any, Dict, List, Optional
from collections import defaultdict

from sim11ah.models import MacFrame


@dataclass
class RxRecord:
    frame: MacFrame
    tx_id: int
    rx_id: int
    start_time: float
    end_time: float
    collided: bool = False


class PhyLayer:
    def __init__(self, node: "Node", cfg: Dict[str, Any]):
        self.node = node
        self.sim = node.sim
        self.cfg = cfg

        self.preamble_time = float(cfg["phy"]["preamble_time"])
        self.header_time = float(cfg["phy"]["header_time"])
        self.slot_time = float(cfg["phy"]["slot_time"])
        self.mode_table = dict(cfg["phy"]["mode_table"])
        self.default_mode = cfg["phy"].get("default_mode", "MCS0")

        self._active_rx: Dict[int, List[RxRecord]] = defaultdict(list)
        self.collision_model = cfg["phy"].get("collision_model", "overlap")

    def compute_tx_duration(self, frame: MacFrame, rate_bps: int) -> float:
        payload_bits = max(0, int(frame.size_bytes) * 8)
        return self.preamble_time + self.header_time + (payload_bits / max(1, rate_bps))

    def is_channel_busy(self, node_id: int) -> bool:
        t = self.sim.engine.now
        for rr in self._active_rx.get(node_id, []):
            if rr.start_time <= t < rr.end_time:
                return True
        return self.sim.medium_is_busy(t)

    def send(self, frame: MacFrame, tx_id: int, rx_id: int, phy_mode: Optional[str] = None) -> None:
        mode = phy_mode or self.default_mode

        # Broadcast
        if rx_id == -1:
            any_dst = None
            for nid in self.sim.nodes:
                if nid != tx_id:
                    any_dst = nid
                    break
            if any_dst is None:
                return

            lk0 = self.sim.topology.get_link(tx_id, any_dst)
            rate0 = int(self.mode_table.get(mode, lk0.rate_bps))
            dur0 = self.compute_tx_duration(frame, rate0)
            t0 = self.sim.engine.now

            self.sim._medium_tx.append((t0, t0 + dur0, tx_id, -1, frame.frame_seq))
            self.sim.engine.schedule(t0 + dur0, self._tx_end, t0, t0 + dur0, tx_id, -1, frame.frame_seq)

            self.sim.log(
                node_id=tx_id, layer="PHY", event="TX_START", frame=frame,
                details={"rx_id": -1, "mode": mode, "rate_bps": rate0, "tx_duration": dur0, "retry": frame.retry, "broadcast": True}
            )

            for nid in self.sim.nodes:
                if nid == tx_id:
                    continue
                lk = self.sim.topology.get_link(tx_id, nid)
                t_rx_start = t0 + lk.prop_delay
                t_rx_end = t_rx_start + dur0
                self.sim.engine.schedule(t_rx_start, self._rx_start, frame, tx_id, nid, t_rx_start, t_rx_end, lk.per)
            return

        lk = self.sim.topology.get_link(tx_id, rx_id)
        rate = int(self.mode_table.get(mode, lk.rate_bps))
        dur = self.compute_tx_duration(frame, rate)

        t0 = self.sim.engine.now
        self.sim._medium_tx.append((t0, t0 + dur, tx_id, rx_id, frame.frame_seq))
        self.sim.engine.schedule(t0 + dur, self._tx_end, t0, t0 + dur, tx_id, rx_id, frame.frame_seq)

        self.sim.log(
            node_id=tx_id, layer="PHY", event="TX_START", frame=frame,
            details={"rx_id": rx_id, "mode": mode, "rate_bps": rate, "tx_duration": dur, "retry": frame.retry}
        )

        t_rx_start = t0 + lk.prop_delay
        t_rx_end = t_rx_start + dur
        self.sim.engine.schedule(t_rx_start, self._rx_start, frame, tx_id, rx_id, t_rx_start, t_rx_end, lk.per)

    def _tx_end(self, t0: float, t1: float, tx_id: int, dst_id: int, frame_seq: int) -> None:
        rec = (t0, t1, tx_id, dst_id, frame_seq)
        try:
            self.sim._medium_tx.remove(rec)
        except ValueError:
            pass

    def _rx_start(self, frame: MacFrame, tx_id: int, rx_id: int, t_rx_start: float, t_rx_end: float, per: float) -> None:
        rr = RxRecord(frame=frame, tx_id=tx_id, rx_id=rx_id, start_time=t_rx_start, end_time=t_rx_end, collided=False)

        # Half-duplex: receiver transmitting?
        for t0, t1, tx, _dst, _fseq in self.sim._medium_tx:
            if tx == rx_id and not (t_rx_end <= t0 or t_rx_start >= t1):
                rr.collided = True
                break

        if self.collision_model == "overlap":
            for existing in self._active_rx[rx_id]:
                if not (t_rx_end <= existing.start_time or t_rx_start >= existing.end_time):
                    existing.collided = True
                    rr.collided = True

        self._active_rx[rx_id].append(rr)

        self.sim.log(node_id=rx_id, layer="PHY", event="RX_START", frame=frame, details={"tx_id": tx_id})
        self.sim.engine.schedule(t_rx_end, self._rx_end, rr, per)

    def _rx_end(self, rr: RxRecord, per: float) -> None:
        rx_list = self._active_rx.get(rr.rx_id, [])
        try:
            rx_list.remove(rr)
        except ValueError:
            pass

        collided = rr.collided
        per_drop = False
        rx_ok = True

        if collided:
            rx_ok = False
            self.sim.stats.phy_collisions += 1
        else:
            u = self.sim.engine.rng.random()
            if u < float(per):
                per_drop = True
                rx_ok = False
                self.sim.stats.phy_per_drops += 1

        self.sim.log(
            node_id=rr.rx_id, layer="PHY", event="RX_END", frame=rr.frame,
            details={"tx_id": rr.tx_id, "collided": collided, "per_drop": per_drop, "rx_ok": rx_ok}
        )

        rx_node = self.sim.nodes.get(rr.rx_id)
        if rx_node is not None:
            rx_node.mac.recv_up_from_phy(rr.frame, collided=collided, per_drop=per_drop, rx_ok=rx_ok)
