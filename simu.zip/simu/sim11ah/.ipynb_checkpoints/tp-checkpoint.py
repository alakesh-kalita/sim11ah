from typing import Any, Dict, Optional
from sim11ah.models import Packet


class TransportLayer:
    def __init__(self, node: "Node", cfg: Dict[str, Any]):
        self.node = node
        self.sim = node.sim
        self.cfg = cfg

    def _log(self, event: str, details: Dict[str, Any], packet: Optional[Packet] = None) -> None:
        self.sim.log(node_id=self.node.node_id, layer="TP", event=event, details=details, packet=packet)

    def send_down(self, packet: Packet) -> None:
        self._log("TX_DOWN", {}, packet=packet)
        self.node.net.send_down(packet)

    def recv_up_from_net(self, packet: Packet) -> None:
        self._log("RX_UP", {}, packet=packet)
        self.node.app.recv_up_from_transport(packet)
