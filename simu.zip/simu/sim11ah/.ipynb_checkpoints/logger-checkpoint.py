import csv
from typing import Any, Dict, List, Optional


class SimLogger:
    def __init__(self):
        self._logs: List[Dict[str, Any]] = []

    @property
    def logs(self) -> List[Dict[str, Any]]:
        return self._logs

    def log(self, rec: Dict[str, Any]) -> None:
        self._logs.append(rec)

    def filter_logs(self, **kwargs) -> List[Dict[str, Any]]:
        out = []
        for r in self._logs:
            ok = True
            for k, v in kwargs.items():
                if r.get(k) != v:
                    ok = False
                    break
            if ok:
                out.append(r)
        return out

    def dump_logs(self, human_readable: bool = True, limit: Optional[int] = None) -> str:
        logs = self._logs if limit is None else self._logs[:limit]
        if not human_readable:
            return "\n".join(str(r) for r in logs)

        lines = []
        for r in logs:
            t = f"{r.get('time', 0.0):.6f}"
            nid = r.get("node_id", "?")
            layer = r.get("layer", "?")
            ev = r.get("event", "?")
            ids = []
            if r.get("packet_seq") is not None:
                ids.append(f"pkt={r.get('packet_seq')}")
            if r.get("net_seq") is not None:
                ids.append(f"net={r.get('net_seq')}")
            if r.get("frame_seq") is not None:
                ids.append(f"frm={r.get('frame_seq')}")
            if r.get("ftype") is not None:
                ids.append(f"type={r.get('ftype')}")
            id_str = (" " + " ".join(ids)) if ids else ""
            details = r.get("details", {})
            lines.append(f"[t={t}] node={nid} {layer}:{ev}{id_str} {details}")
        return "\n".join(lines)

    def export_logs_csv(self, path: str) -> None:
        fieldnames = [
            "time", "node_id", "layer", "event",
            "packet_seq", "net_seq", "frame_seq", "tx_seq",
            "ftype", "src", "dst",
            "details"
        ]
        with open(path, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fieldnames)
            w.writeheader()
            for r in self._logs:
                w.writerow({
                    "time": r.get("time", 0.0),
                    "node_id": r.get("node_id", ""),
                    "layer": r.get("layer", ""),
                    "event": r.get("event", ""),
                    "packet_seq": r.get("packet_seq", ""),
                    "net_seq": r.get("net_seq", ""),
                    "frame_seq": r.get("frame_seq", ""),
                    "tx_seq": r.get("tx_seq", ""),
                    "ftype": r.get("ftype", ""),
                    "src": r.get("src", ""),
                    "dst": r.get("dst", ""),
                    "details": repr(r.get("details", {})),
                })
