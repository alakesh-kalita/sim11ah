from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass
class Packet:
    packet_seq: int
    src: int
    dst: int
    size_bytes: int
    gen_time: float
    payload: bytes = b""


@dataclass
class NetPDU:
    net_seq: int
    src: int
    dst: int
    next_hop: int
    packet: Packet


@dataclass
class MacFrame:
    ftype: str
    src: int
    dst: int
    size_bytes: int
    frame_seq: int
    tx_seq: int
    retry: int = 0
    net_pdu: Optional[NetPDU] = None
    ctrl: Dict[str, Any] = field(default_factory=dict)
