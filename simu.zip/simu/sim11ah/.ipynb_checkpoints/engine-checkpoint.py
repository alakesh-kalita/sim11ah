import heapq
import random
from typing import Any, Callable, List, Optional, Tuple


class EventEngine:
    def __init__(self, seed: int = 0):
        self.now: float = 0.0
        self._q: List[Tuple[float, int, Callable[..., None], Tuple[Any, ...]]] = []
        self._seq: int = 0
        self.rng = random.Random(seed)
        self._stopped: bool = False

    def schedule(self, time_abs: float, cb: Callable[..., None], *args: Any) -> None:
        if time_abs < self.now:
            time_abs = self.now
        self._seq += 1
        heapq.heappush(self._q, (time_abs, self._seq, cb, args))

    def schedule_in(self, delay: float, cb: Callable[..., None], *args: Any) -> None:
        self.schedule(self.now + max(0.0, delay), cb, *args)

    def run(self, until: Optional[float] = None) -> None:
        self._stopped = False
        while self._q and not self._stopped:
            t, _, cb, args = heapq.heappop(self._q)
            if until is not None and t > until:
                self.now = until
                break
            self.now = t
            cb(*args)

    def stop(self) -> None:
        self._stopped = True
