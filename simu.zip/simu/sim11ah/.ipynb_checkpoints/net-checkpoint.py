from typing import Any, Dict, Optional
from sim11ah.models import NetPDU, Packet


class NetworkLayer:
    def __init__(self, node: "Node", cfg: Dict[str, Any]):
        self.node = node
        self.sim = node.sim
        self.cfg = cfg
        self.net_seq_ctr = 0

    def _log(self, event: str, details: Dict[str, Any],
             net_pdu: Optional[NetPDU] = None,
             packet: Optional[Packet] = None) -> None:
        self.sim.log(node_id=self.node.node_id, layer="NET", event=event,
                     details=details, net_pdu=net_pdu, packet=packet)

    def resolve_next_hop(self, dst: int) -> int:
        if self.node.node_id == 0:
            return dst
        if dst == 0:
            return 0
        return 0

    def send_down(self, packet: Packet) -> None:
        self.net_seq_ctr += 1
        next_hop = self.resolve_next_hop(packet.dst)
        pdu = NetPDU(net_seq=self.net_seq_ctr, src=packet.src, dst=packet.dst, next_hop=next_hop, packet=packet)
        self._log("TX_DOWN", {"next_hop": next_hop}, net_pdu=pdu)
        self.node.mac.send_down(pdu)

    def recv_up_from_mac(self, net_pdu: NetPDU) -> None:
        self._log("RX_UP", {"next_hop": net_pdu.next_hop}, net_pdu=net_pdu)

        if self.node.node_id == 0:
            if net_pdu.dst == 0:
                self.node.transport.recv_up_from_net(net_pdu.packet)
                return
            self.send_down(net_pdu.packet)
            return

        if net_pdu.dst == self.node.node_id:
            self.node.transport.recv_up_from_net(net_pdu.packet)
        else:
            self.sim.stats.packets_dropped += 1
            self._log("DROP", {"reason": "not_for_me"}, net_pdu=net_pdu)
