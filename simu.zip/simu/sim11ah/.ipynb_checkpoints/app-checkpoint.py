import math
import random
from typing import Any, Dict, Optional

from sim11ah.models import Packet


class TrafficModel:
    def next_interval(self, rng: random.Random) -> float:
        raise NotImplementedError


class PeriodicTraffic(TrafficModel):
    def __init__(self, interval: float):
        self.interval = float(interval)

    def next_interval(self, rng: random.Random) -> float:
        return self.interval


class PoissonTraffic(TrafficModel):
    def __init__(self, rate_lambda: float):
        self.rate_lambda = float(rate_lambda)

    def next_interval(self, rng: random.Random) -> float:
        u = rng.random()
        u = min(max(u, 1e-12), 1.0 - 1e-12)
        return -math.log(1.0 - u) / max(1e-12, self.rate_lambda)


class ApplicationLayer:
    def __init__(self, node: "Node", cfg: Dict[str, Any]):
        self.node = node
        self.sim = node.sim
        self.cfg = cfg
        self.packet_size = int(cfg["app"]["packet_size_bytes"])
        self.dst_mode = cfg["app"]["dst_mode"]
        self.enable_sink = bool(cfg["app"]["enable_sink"])
        self._traffic: Optional[TrafficModel] = None
        self._running = False

    def _log(self, event: str, details: Dict[str, Any], packet: Optional[Packet] = None) -> None:
        self.sim.log(node_id=self.node.node_id, layer="APP", event=event, details=details, packet=packet)

    def set_traffic_model(self, tm: Optional[TrafficModel]) -> None:
        self._traffic = tm

    def start(self) -> None:
        if self.node.node_id == 0:
            self._running = True
            return
        if self._traffic is None:
            return
        self._running = True
        start_offset = 0.01 * self.node.node_id
        self.sim.engine.schedule_in(start_offset, self._generate_one)

    def _pick_dst(self) -> int:
        if self.dst_mode == "ap":
            return 0
        stas = [i for i in self.sim.nodes.keys() if i != 0 and i != self.node.node_id]
        if not stas:
            return 0
        return stas[self.sim.engine.rng.randrange(0, len(stas))]

    def _generate_one(self) -> None:
        if not self._running or self._traffic is None:
            return
        dst = self._pick_dst()

        pkt = Packet(
            packet_seq=self.sim.next_packet_seq(),
            src=self.node.node_id,
            dst=dst,
            size_bytes=self.packet_size,
            gen_time=self.sim.engine.now,
            payload=b"x" * min(self.packet_size, 32)
        )

        self.sim.stats.packets_generated += 1
        self.sim.stats.generated_by_src[self.node.node_id] += 1

        self._log("GENERATE", {"size_bytes": pkt.size_bytes}, packet=pkt)
        self.node.transport.send_down(pkt)

        dt = self._traffic.next_interval(self.sim.engine.rng)
        self.sim.engine.schedule_in(dt, self._generate_one)

    def recv_up_from_transport(self, packet: Packet) -> None:
        if not self.enable_sink:
            return
        if packet.dst != self.node.node_id:
            return
        self.sim.stats.packets_delivered += 1
        self.sim.stats.delivered_by_dst[self.node.node_id] += 1
        delay = self.sim.engine.now - packet.gen_time
        self.sim.stats.delays.append(delay)
        self._log("DELIVER", {"delay": delay}, packet=packet)
