from typing import Any, Dict


def default_config(raw_enable: bool, traffic_mode: str) -> Dict[str, Any]:
    phy_mode_table = {
        "MCS0": 150_000,
        "MCS1": 300_000,
        "MCS2": 600_000,
        "MCS3": 1_200_000,
    }
    cfg = {
        "phy": {
            "preamble_time": 0.00032,
            "header_time": 0.00008,
            "slot_time": 0.000052,
            "mode_table": phy_mode_table,
            "default_mode": "MCS1",
            "collision_model": "overlap",
            "per_model": "link_per",
        },
        "mac": {
            "raw_enable": bool(raw_enable),
            "beacon_interval": 0.5,
            "dtim_period": 2,
            "raw_slot_duration": 0.05,
            "raw_num_slots": 10,
            "raw_guard": 0.0005,
            "sifs": 0.00016,
            "difs": 0.00034,
            "ack_timeout": 0.01,
            "ack_guard": 0.0002,
            "cw_min": 15,
            "cw_max": 1023,
            "retry_limit": 4,
            "ack_size_bytes": 14,
            "beacon_size_bytes": 80,
            "data_mac_overhead_bytes": 34,
        },
        "net": {"net_header_bytes": 16},
        "tp": {"mode": "udp_like"},
        "app": {
            "traffic": traffic_mode,
            "packet_size_bytes": 400,
            "dst_mode": "random_sta",
            "enable_sink": True,
            "periodic_interval": 0.2,
            "poisson_lambda": 5.0,
        }
    }
    return cfg
